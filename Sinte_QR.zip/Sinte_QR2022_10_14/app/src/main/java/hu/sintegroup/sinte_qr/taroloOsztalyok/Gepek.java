package hu.sintegroup.sinte_qr.taroloOsztalyok;

public class Gepek {

    public Gepek(){

    }

    private String gepSzama;
    private String gepNeve;
    private String gepLeltariSzama;
    private String gepElhelyezkedese;
    private String gepTipusa;
    private String gepMerete;
    private String gepMunkavegzesJellege;
    private String gepQRSzama;


    public void setGepElhelyezkedese(String gepElhelyezkedese) {
        this.gepElhelyezkedese = gepElhelyezkedese;
    }

    public void setGepTipusa(String gepTipusa) {
        this.gepTipusa = gepTipusa;
    }


    public void setGepLeltariSzama(String gepLeltariSzama) {
        this.gepLeltariSzama = gepLeltariSzama;
    }

    public void setGepMerete(String gepMerete) {
        this.gepMerete = gepMerete;
    }

    public void setGepMunkavegzesJellege(String gepMunkavegzesJellege) {
        this.gepMunkavegzesJellege = gepMunkavegzesJellege;
    }

    public void setGepSzama(String gepSzama) {
        this.gepSzama = gepSzama;
    }

    public void setGepNeve(String gepNeve) {
        this.gepNeve = gepNeve;
    }


    public void setGepQRSzama(String gepQRSzama) {
        this.gepQRSzama = gepQRSzama;
    }

    public String getGepElhelyezkedese() {
        return gepElhelyezkedese;
    }

    public String getGepTipusa() {
        return gepTipusa;
    }

    public String getGepQRSzama() {
        return gepQRSzama;
    }
}
